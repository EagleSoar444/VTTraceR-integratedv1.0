# VT Tracer Comms HTML GitHub Preview v0.5

Generated: 2026-05-10T13:01:10.378294

## Use on GitHub Pages

1. Upload `index.html` to the root of a GitHub repository.
2. Go to Settings → Pages.
3. Choose `Deploy from branch`.
4. Select `main` and `/root`.
5. Open the generated GitHub Pages URL.

This version is HTML-only and does not require `.js`, `.jsx`, JSON import, npm, or a build step.
